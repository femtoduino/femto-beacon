/* This file has been prepared for Doxygen automatic documentation generation.*/
/** \file *********************************************************************
 *
 * \brief
 * XMEGA TWI slave driver source file.
 *
 * This file contains the function implementations the XMEGA TWI slave
 * driver.
 *
 * The driver is not intended for size and/or speed critical code, since
 * most functions are just a few lines of code, and the function call
 * overhead would decrease code performance. The driver is intended for
 * rapid prototyping and documentation purposes for getting started with
 * the XMEGA TWI slave module.
 *
 * For size and/or speed critical code, it is recommended to copy the
 * function contents directly into your application instead of making
 * a function call.
 *
 * Several functions use the following construct:
 * "some_register = ... | (some_parameter ? SOME_BIT_bm : 0) | ..."
 * Although the use of the ternary operator ( if ? then : else ) is
 * discouraged, in some occasions the operator makes it possible to write
 * pretty clean and neat code. In this driver, the construct is used to
 * set or not set a configuration bit based on a boolean input parameter,
 * such as the "some_parameter" in the example above.
 *
 * \par Application note:
 * AVR1308: Using the XMEGA TWI
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "twi_slave_header.h"

/*! Defining an example slave address. */
#define SLAVE_ADDRESS    0x55

/*! Defining number of bytes in buffer. */
#define NUM_BYTES    8

/*! CPU speed 2MHz, BAUDRATE 100kHz and Baudrate Register Settings */
#define CPU_SPEED    2000000
#define BAUDRATE    100000
#define TWI_BAUDSETTING TWI_BAUD(CPU_SPEED, BAUDRATE)

#define FLASH_APP_START_BLOCK    ((uint32_t)(0x0000))
#define FLASH_APP_END_BLOCK	     ((uint32_t)(0x1FFFF))//Only Application Section
#define	FLASH_APP_END             0x20000             //Including App Table

// Global variables.
TWI_Slave_t twiSlave;
bool Enter_Programming_Mode = false;
bool Page_Data_Full = false;
bool Write_Pending, New_Page = true;
uint8_t Write_Buffer[FLASH_PAGE_SIZE];
uint8_t Read_Buffer[FLASH_PAGE_SIZE];
TWI_State_t TWI_State;

/** \brief Initalizes TWI slave driver structure.
 *
 *  Initialize the instance of the TWI Slave and set the appropriate values.
 *
 *  \param twi                  The TWI_Slave_t struct instance.
 *  \param module               Pointer to the TWI module.
 *  \param processDataFunction  Pointer to the function that handles incoming data.
 */
void TWI_SlaveInitializeDriver(TWI_Slave_t *twi,
                               TWI_t *module,
                               void (*processDataFunction) (void))
{
	twi->interface = module;
	twi->Process_Data = processDataFunction;
	twi->bytesReceived = 0;
	twi->bytesSent = 0;
	twi->status = TWIS_STATUS_READY;
	twi->result = TWIS_RESULT_UNKNOWN;
	twi->abort = false;
        TWI_State = TWI_Start;
        Write_Pending = false;
}


/** \brief Initialize the TWI module.
 *
 *  Enables interrupts on address recognition and data available.
 *  Remember to enable interrupts globally from the main application.
 *
 *  \param twi        The TWI_Slave_t struct instance.
 *  \param address    Slave address for this module.
 *  \param intLevel   Interrupt level for the TWI slave interrupt handler.
 */
void TWI_SlaveInitializeModule(TWI_Slave_t *twi,
                               uint8_t address,
                               TWI_SLAVE_INTLVL_t intLevel)
{
	twi->interface->SLAVE.CTRLA = intLevel |
	                              TWI_SLAVE_DIEN_bm |
	                              TWI_SLAVE_APIEN_bm |
	                              TWI_SLAVE_ENABLE_bm;
	twi->interface->SLAVE.ADDR = (address<<1);
}


/** \brief Common TWI slave interrupt service routine.
 *
 *  Handles all TWI transactions and responses to address match, data reception,
 *  data transmission, bus error and data collision.
 *
 *  \param twi The TWI_Slave_t struct instance.
 */
void TWI_SlaveInterruptHandler(TWI_Slave_t *twi)
{
	uint8_t currentStatus = twi->interface->SLAVE.STATUS;

	// If bus error.
	if (currentStatus & TWI_SLAVE_BUSERR_bm) {
		twi->bytesReceived = 0;
		twi->bytesSent = 0;
		twi->result = TWIS_RESULT_BUS_ERROR;
		twi->status = TWIS_STATUS_READY;
	}

	// If transmit collision.
	else if (currentStatus & TWI_SLAVE_COLL_bm) {
		twi->bytesReceived = 0;
		twi->bytesSent = 0;
		twi->result = TWIS_RESULT_TRANSMIT_COLLISION;
		twi->status = TWIS_STATUS_READY;
	}

	// If address match.
	else if ((currentStatus & TWI_SLAVE_APIF_bm) &&
	        (currentStatus & TWI_SLAVE_AP_bm)) {

		TWI_SlaveAddressMatchHandler(twi);
	}

	// If stop (only enabled through slave read transaction).
	else if (currentStatus & TWI_SLAVE_APIF_bm) {
		TWI_SlaveStopHandler(twi);
	}

	// If data interrupt.
	else if (currentStatus & TWI_SLAVE_DIF_bm) {
		TWI_SlaveDataHandler(twi);
	}

	// If unexpected state.
	else {
		TWI_SlaveTransactionFinished(twi, TWIS_RESULT_FAIL);
	}
}

/** \brief TWI address match interrupt handler.
 *
 *  Prepares TWI module for transaction when an address match occures.
 *
 *  \param twi The TWI_Slave_t struct instance.
 */
void TWI_SlaveAddressMatchHandler(TWI_Slave_t *twi)
{
	// If application signalling need to abort (error occured).
	if (twi->abort) {
		twi->interface->SLAVE.CTRLB = TWI_SLAVE_CMD_COMPTRANS_gc;
		TWI_SlaveTransactionFinished(twi, TWIS_RESULT_ABORTED);
		twi->abort = false;
	} else {
		twi->status = TWIS_STATUS_BUSY;
		twi->result = TWIS_RESULT_UNKNOWN;

		// Disable stop interrupt.
		uint8_t currentCtrlA = twi->interface->SLAVE.CTRLA;
		twi->interface->SLAVE.CTRLA = currentCtrlA & ~TWI_SLAVE_PIEN_bm;

		twi->bytesReceived = 0;
		twi->bytesSent = 0;

		// Send ACK, wait for data interrupt.
		twi->interface->SLAVE.CTRLB = TWI_SLAVE_CMD_RESPONSE_gc;
	}
}


/** \brief TWI stop condition interrupt handler.
 *
 *  \param twi The TWI_Slave_t struct instance.
 */
void TWI_SlaveStopHandler(TWI_Slave_t *twi)
{
	// Disable stop interrupt.
	uint8_t currentCtrlA = twi->interface->SLAVE.CTRLA;
	twi->interface->SLAVE.CTRLA = currentCtrlA & ~TWI_SLAVE_PIEN_bm;

	// Process the received data.
	twi->Process_Data();
	TWI_SlaveTransactionFinished(twi, TWIS_RESULT_OK);

	// Flush the buffers used.
	flush_buffer();
}


/** \brief TWI data interrupt handler.
 *
 *  Calls the appropriate slave read or write handler.
 *
 *  \param twi The TWI_Slave_t struct instance.
 */
void TWI_SlaveDataHandler(TWI_Slave_t *twi)
{
	if (twi->interface->SLAVE.STATUS & TWI_SLAVE_DIR_bm) {
		TWI_SlaveWriteHandler(twi);
	} else {
		TWI_SlaveReadHandler(twi);
	}
}


/** \brief TWI slave read interrupt handler.
 *
 *  Handles TWI slave read transactions and responses.
 *
 *  \param twi The TWI_Slave_t struct instance.
 */
void TWI_SlaveReadHandler(TWI_Slave_t *twi)
{
	// Enable stop interrupt.
	uint8_t currentCtrlA = twi->interface->SLAVE.CTRLA;
	twi->interface->SLAVE.CTRLA = currentCtrlA | TWI_SLAVE_PIEN_bm;

	// If free space in buffer.
	if (twi->bytesReceived < TWIS_RECEIVE_BUFFER_SIZE) {
		// Fetch data.
		uint8_t data = twi->interface->SLAVE.DATA;
		twi->receivedData[twi->bytesReceived] = data;

		twi->bytesReceived++;

		// If application signalling need to abort (error occured),
		// complete transaction and wait for next START. Otherwise
		// send ACK and wait for data interrupt.
		if (twi->abort) {
			twi->interface->SLAVE.CTRLB = TWI_SLAVE_CMD_COMPTRANS_gc;
			TWI_SlaveTransactionFinished(twi, TWIS_RESULT_ABORTED);
			twi->abort = false;
		} else {
			twi->interface->SLAVE.CTRLB = TWI_SLAVE_CMD_RESPONSE_gc;
		}
	}
	// If buffer overflow, send NACK and wait for next START. Set
	// result buffer overflow.
	else {
		twi->interface->SLAVE.CTRLB = TWI_SLAVE_ACKACT_bm |
		                              TWI_SLAVE_CMD_COMPTRANS_gc;
		TWI_SlaveTransactionFinished(twi, TWIS_RESULT_BUFFER_OVERFLOW);
	}
}


/** \brief TWI slave write interrupt handler.
 *
 *  Handles TWI slave write transactions and responses.
 *
 *  \param twi The TWI_Slave_t struct instance.
 */
void TWI_SlaveWriteHandler(TWI_Slave_t *twi)
{
	// If NACK, slave write transaction finished.
	if ((twi->bytesSent > 0) && (twi->interface->SLAVE.STATUS &
	                             TWI_SLAVE_RXACK_bm)) {

		twi->interface->SLAVE.CTRLB = TWI_SLAVE_CMD_COMPTRANS_gc;
		TWI_SlaveTransactionFinished(twi, TWIS_RESULT_OK);
	}
	// If ACK, master expects more data.
	else {
		if (twi->bytesSent < TWIS_SEND_BUFFER_SIZE) {
			uint8_t data = twi->sendData[twi->bytesSent];
			twi->interface->SLAVE.DATA = data;
			twi->bytesSent++;

			// Send data, wait for data interrupt.
			twi->interface->SLAVE.CTRLB = TWI_SLAVE_CMD_RESPONSE_gc;
		}
		// If buffer overflow.
		else {
			twi->interface->SLAVE.CTRLB = TWI_SLAVE_CMD_COMPTRANS_gc;
			TWI_SlaveTransactionFinished(twi, TWIS_RESULT_BUFFER_OVERFLOW);
		}
	}
}


/** \brief TWI transaction finished function.
 *
 *  Prepares module for new transaction.
 *
 *  \param twi    The TWI_Slave_t struct instance.
 *  \param result The result of the transaction.
 */
void TWI_SlaveTransactionFinished(TWI_Slave_t *twi, uint8_t result)
{
	twi->result = result;
	twi->status = TWIS_STATUS_READY;
}

/** \brief Enable TWI module.
 *
 *  Enables TWI slave module with assigns interrupt level.
 */
void TWI_InitModule()
{
	// Initialize TWI slave.
	TWI_SlaveInitializeDriver(&twiSlave, &TWIC, TWIC_SlaveProcessData);
	TWI_SlaveInitializeModule(&twiSlave,
	                          SLAVE_ADDRESS,
	                          TWI_SLAVE_INTLVL_LO_gc);

	// Enable LO interrupt level.
	PMIC.CTRL |= PMIC_LOLVLEN_bm;

}

/** \brief Processes the received data.
 *
 *  Checks the commands received and performs the appropriate action.
 */
void TWIC_SlaveProcessData()
{
	uint32_t bufIndex = twiSlave.bytesReceived;
	uint32_t address = 0;
	bool Data_Ready = false;
	uint16_t Data_Length;
	uint8_t Command = 0;
	uint16_t temp;
	uint32_t read_write_page_address;

	void (*funcptr)(void) = 0x0000;

	// First three bytes received are address bytes.
	address = twiSlave.receivedData[2];
	address = (address << 8) | (twiSlave.receivedData[1]);
	address = (address << 8) | (twiSlave.receivedData[0]);

	// Next byte received is the Command/operation to be performed.
	Command = twiSlave.receivedData[3];

	// Check for the received command.
	switch(Command)
	{
	// 'P' - Enter programming mode.
	case 'P':
		//Confirm TWI is Start state and then change it programming mode.
		if(TWI_State == TWI_Start) {
			TWI_State = TWI_Prog_Mode;
		}
		break;

	// 'E' - Erase Application section.
	case 'E':
		// Check TWI state and erase application section.
		if(TWI_State == TWI_Get_Data) {
			SP_EraseApplicationSection();
			SP_WaitForSPM();
		}
		break;

	// 'D' - Following information is data to be programmed.
	case 'D':
	if(TWI_State == TWI_Get_Data) {
		// Data_Length is total number of bytes received excluding
		// 4 bytes - 3 address bytes and one command byte.
		Data_Length = bufIndex-4;

		// Confirm that 256 bytes of data has been received.
		if(Data_Length == (FLASH_PAGE_SIZE/2)) {

			// Check whether data received is first half of a page.
			if(New_Page == true) {

				// Copy the data to Write buffer.
				for (int i = 0; i < FLASH_PAGE_SIZE/2; i++) {
					Write_Buffer[i] = twiSlave.receivedData[i+4];
				}

				// Set flag to indicate next data will be second half of a page
				New_Page = false;
				// Set flag to indicate data is pending to be written to flash.
				Write_Pending = true;
			}

			// Check whether received data is second half of a page.
			else if(New_Page == false) {
				int j = 4;

				// Copy the data to Write buffer.
				for(int i = FLASH_PAGE_SIZE/2; i < FLASH_PAGE_SIZE; i++) {
					Write_Buffer[i] = twiSlave.receivedData[j];
					j++;
				}

				// Set flag to indicate next data will be first half of a page.
				New_Page = true;
				// Set flag to indicate data is ready to be written to flash.
				Data_Ready = true;
			}
		}
		else {
			Data_Ready = false; 
			twiSlave.sendData[0] = Write_Pending;
		}
	}
	break;

	// 'X' - Exit programming mode and reset the device.
	case 'X':
	if(TWI_State == TWI_Prog_Mode || TWI_State == TWI_Get_Data) {
		// Set TWI State to Start state.
		TWI_State = TWI_Start;
		PORTE.OUT = TWI_State;
		// Reset the device.
		funcptr();
	}
	break;
	}

	PORTE.OUT = TWI_State;

	if(Data_Ready == true) {
		uint16_t j=0;

		// Check whether given address is within Application section.
		if(address < FLASH_APP_END_BLOCK) {
			read_write_page_address  = address;

			// Load Flash buffer.
			for(uint16_t i=0; i < FLASH_PAGE_SIZE/2 ; i++) {
				// Create word from bytes
				temp = Write_Buffer[j];
				j++;
				temp = (temp) | (Write_Buffer[j]<<8);

				SP_LoadFlashWord(address, temp);

				j++;
				address +=2;
			}

			// Write the Flash Page Buffer.
			SP_EraseWriteApplicationPage(read_write_page_address);
			SP_WaitForSPM();
		}

		// Set flag to indicate there is no more data to be programmed.
		Data_Ready = false;
		// Set flag to indicate that write to flash has been completed.
		Write_Pending = false;
		// Set the status for master to read.
		twiSlave.sendData[0] = Write_Pending;
	}
}

/** \brief Flushes the buffer.
 *
 *  Cleans the buffer used to store received data.
 */
void flush_buffer()
{
	for(uint16_t i = 0;i < TWIS_RECEIVE_BUFFER_SIZE; i++)
	twiSlave.receivedData[i] = 0;
}