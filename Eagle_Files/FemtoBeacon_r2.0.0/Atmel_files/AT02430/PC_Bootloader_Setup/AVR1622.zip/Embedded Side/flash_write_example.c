/** \file
 *
 * \brief  XMEGA Self-programming through TWI example source.
 *
 * This file contains an example application that demonstrates the
 * Self-programming with data through TWI interface. It shows how to program
 * a HEX file to Application Section.
 *
 * \par Application note:
 * AVR1622: TWI Bootloader for XMEGA
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "twi_slave_header.h"

/*! Macro defined to read from the Application Table Section. */
#define appTable(__tableIndex)	SP_ReadByte(APPTABLE_SECTION_START + __tableIndex)

// Test message to write to the signature row.
uint8_t message[32] = {"This is the user signature row.."};

#define	PROGPORT PORTB.OUT
#define	PROGPIN	 PORTB.IN
#define	PROG_NO	 PIN0_bp

extern TWI_Slave_t twiSlave;  
extern int count;
extern bool Enter_Programming_Mode;
extern bool Page_Data_Full;
extern char Data[258];
extern TWI_State_t TWI_State;

/** \brief Function to erase one page in the Application Table Section.
 *
 *  \note The maximum pageAddress must not be exceeded. The maximum number of 
 *        pages can be found in the datasheet. For the ATxmega128A1, the maximum
 *        number of pages in the application table is 16.
 *
 *  \param pageAddress Page address to the page to erase.
 */
void EraseAppTablePage(uint8_t pageAddress)
{
	// Calculate actual start address of the page.
	uint16_t tableAddress = (pageAddress * FLASH_PAGE_SIZE);
	
	// Perform page erase.
	SP_EraseApplicationPage(APPTABLE_SECTION_START + tableAddress);

	// Wait for NVM to finish.
	SP_WaitForSPM();
}


/** \brief Function to do an atomic erase-write on one page in the Application Table Section.
 *
 *  \note The maximum pageAddress must not be exceeded. The maximum number of 
 *        pages can be found in the datasheet. For the ATxmega128A1, the maximum
 *        number of pages in the application table is 16.
 *
 *  \param pageAddress Page address to the page to erase/write.
 */
void EraseWriteAppTablePage(uint8_t pageAddress)
{
	// Calculate actual start address of the page.
	uint16_t tableAddress = (pageAddress * FLASH_PAGE_SIZE);
	
	// Perform page erase.
	SP_EraseWriteApplicationPage(APPTABLE_SECTION_START + tableAddress);

	// Wait for NVM to finish.
	SP_WaitForSPM();
}


/** \brief Function to program one page in the Application Table Section.
 *
 *  \note The maximum pageAddress must not be exceeded. The maximum number of 
 *        pages can be found in the datasheet. For the ATxmega128A1, the maximum
 *        number of pages in the application table is 16.
 *
 *  \param pageAddress Page address to the page to write.
 */
void WriteAppTablePage(uint8_t pageAddress)
{
	// Calculate actual start address of the page.
	uint16_t tableAddress = (pageAddress * FLASH_PAGE_SIZE);
	
	// Perform page write.
	SP_WriteApplicationPage(APPTABLE_SECTION_START + tableAddress);

	// Wait for NVM to finish.
	SP_WaitForSPM();
}


/** \brief Function to load one word into page buffer.
 *
 *  \param tableAddress Address in buffer to write the word.
 *  \param lowByte      The low byte of the word to load.
 *  \param highByte     The high byte of the word to load.
 */
void LoadAppTableWord(uint16_t tableAddress, uint8_t lowByte, uint8_t highByte)
{
	// Perform word load.
	SP_LoadFlashWord(tableAddress, ((uint16_t) highByte << 8) | lowByte);

	// Wait for NVM to finish.
	SP_WaitForSPM();
}


/** \brief Function to read a flash page.
 *
 *  \note The maximum pageAddress must not be exceeded. The maximum number of 
 *        pages can be found in the datasheet. For the ATxmega128A1, the maximum
 *        number of pages in the application table is 16.
 *
 *  \param data         Pointer to a data buffer to store the data.
 *  \param pageAddress  Page address to read from. 
 */
void ReadFlashPage(const uint8_t * data, uint8_t pageAddress)
{
	// Calculate actual start address of the page.
	uint16_t tableAddress = (pageAddress * FLASH_PAGE_SIZE);
	
	// Read the flash page into the buffer.
	SP_ReadFlashPage(data, APPTABLE_SECTION_START + tableAddress);
}


/** \brief Example to show how to read and write to the flash.
 */
int main(void)
{
	// Move Interrupt vector table to Boot Section.
	uint8_t temp = PMIC.CTRL | PMIC_IVSEL_bm;
	CCP = CCP_IOREG_gc;
	PMIC.CTRL = temp;

	// Set PORTE as output.
	PORTE.DIRSET = 0xFF;

	// Set up function pointer to RESET vector.
	void (*funcptr)(void ) = 0x0000;

	// Enable pull-up on PROG_NO line on PROGPORT.
	PROGPORT |= (1<<PROG_NO);

	// Enable TWI module and initialize.
	TWI_InitModule();

	// Enable global interrupts.
	sei();

	// Check whether PROGPIN is pressed.
	if( !(PROGPIN & (1<<PROG_NO)) ) {
		PORTE.OUT = 0xAA;         

		// Wait till TWI has entered programming mode.
		while (!(TWI_State == TWI_Prog_Mode));
			// Change the TWI State to TWI_Get_Data.
			TWI_State = TWI_Get_Data;

		// Eternal loop
		while (1)
		{
			asm("nop");
		}
	}
	else {
		PORTE.OUT = 0x55; 

		// Lock SPM
		SP_WaitForSPM();
		SP_LockSPM();
		EIND = 0x00;

		// Move back Interrupt vector table to Application section
		uint8_t temp = PMIC.CTRL & ~PMIC_IVSEL_bm;
		CCP = CCP_IOREG_gc;
		PMIC.CTRL = temp;
   
		funcptr();
	}
}

/** 
 * \internal  
 * \brief TWI interrupt handler.
 */
ISR(TWIC_TWIS_vect)
{
	TWI_SlaveInterruptHandler(&twiSlave);
}
