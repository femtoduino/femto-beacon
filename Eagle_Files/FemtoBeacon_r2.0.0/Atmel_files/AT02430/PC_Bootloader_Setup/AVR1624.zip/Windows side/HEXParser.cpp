/** \file
 *
 * \brief  AVR TWIGEN HEX Parser file
 *
 * This file implements functions for parsing, reading and writing an 
 * Intel extended HEX file
 *
 * \par Application note:
 * AVR1624: Using ATxmega128A1 Xplain Kit as USB to TWI Bridge
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */
#include "HEXParser.hpp"

// Internal struct for managing HEX records 

// Intel HEX file record
/** \brief Struct for Intel HEX file 
*/
struct HEXRecord
{
	// Record length in number of data bytes.
	unsigned char length;
	// Offset address.
	unsigned long offset;
	// Record type.
	unsigned char type;
	// Optional data bytes.
	unsigned char * data;
};

/** \brief Writes HEX record to a file
 *
 *  \param f    File to which record is to be written
 *  \param recp Pointer to HEX record
 */
void HEXFile::writeRecord( ofstream & f, HEXRecord * recp )
{
	unsigned char checksum;
	long recordPos; // Position inside record data field

	// Calculate checksum
	checksum = recp->length;
	checksum += (unsigned char) ((recp->offset >> 8) & 0xff);
	checksum += (unsigned char) (recp->offset & 0xff);
	checksum += recp->type;

	// Write record header
	f.fill('0');
	f << ":" << hex
		<< setw(2) << (long) recp->length
		<< setw(4) << (long) recp->offset
		<< setw(2) << (long) recp->type;

	// Write data bytes
	for( recordPos = 0; recordPos < recp->length; recordPos++ ) {
		checksum += recp->data[ recordPos ]; // Further checksum calculation
		f << hex << setw(2) << (long) recp->data[ recordPos ];
	}

	// Write checksum
	checksum = 0 - checksum; // Final checksum preparation
	f << setw(2) << (long) checksum << endl;

	// Check for errors
	if( !f.good() )
		throw new ErrorMsg( "Error writing HEX record to file!" );
}

/** \brief Parses through the HEX record
 *
 *  \param hexLine Line to be parsed
 *  \param recp    Pointer to HEX record
 */
void HEXFile::parseRecord( const string & hexLine, HEXRecord * recp )
{
	unsigned char checksum;
	long recordPos; // Position inside record data fields.

	if( hexLine.size() < 11 ) // At least 11 characters.
		throw new ErrorMsg( "Wrong HEX file format, missing fields! "
				"Line from file was: (" + hexLine + ")." );

	// Check format for line
	if( hexLine[0] != ':' ) // Always start with colon.
		throw new ErrorMsg( "Wrong HEX file format, does not start with colon! "
				"Line from file was: (" + hexLine + ")." );

	// Parse length, offset and type
	recp->length = Util.convertHex( hexLine.substr( 1, 2 ) );
	recp->offset = Util.convertHex( hexLine.substr( 3, 4 ) );
	recp->type = Util.convertHex( hexLine.substr( 7, 2 ) );

	// We now know how long the record should be
	if( hexLine.size() < (11+recp->length*2) )
		throw new ErrorMsg( "Wrong HEX file format, missing fields! "
				"Line from file was: (" + hexLine + ")." );

	// Process checksum
	checksum = recp->length;
	checksum += (unsigned char) ((recp->offset >> 8) & 0xff);
	checksum += (unsigned char) (recp->offset & 0xff);
	checksum += recp->type;

	// Parse data fields
	if( recp->length ) {
		recp->data = new unsigned char[ recp->length ];

		// Read data from record
		for( recordPos = 0; recordPos < recp->length; recordPos++ ) {
			recp->data[ recordPos ] = Util.convertHex( hexLine.substr( 9 + recordPos*2, 2 ) );
			checksum += recp->data[ recordPos ];
		}
	}

	// Correct checksum?
	checksum += Util.convertHex( hexLine.substr( 9 + recp->length*2, 2 ) );
	if( checksum != 0 ) {
		throw new ErrorMsg( "Wrong checksum for HEX record! "
				"Line from file was: (" + hexLine + ")." );
	}
}

/** \brief Constructor
 *
 * Initializes maximum data buffer size and the buffer with specified value
 *
 *  \param buffersize Maximum data buffer size
 *  \param value      Value with which buffer will be initialized
 */
HEXFile::HEXFile( long buffersize, long value )
{
	if( buffersize <= 0 )
		throw new ErrorMsg( "Cannot have zero-size HEX buffer!" );

	data = new unsigned char[ buffersize ];

	if( !data )
		throw new ErrorMsg( "Memory allocation failed for HEX-line-buffer!" );

	size = buffersize;

	clearAll( value );
}

/** \brief Destructor
 *
 * Deallocates all previously allocated memory
 */
HEXFile::~HEXFile()
{
	if( data ) delete data;
}

/** \brief Reads data from a HEX file
 *
 *  \param _filename String containing the name of HEX file
 */
void HEXFile::readFile( const string & _filename )
{
	ifstream f;
	// Contains one line of the HEX file.
	string hexLine;
	// Temp record.
	HEXRecord rec;

	// Base address for extended addressing modes.
	long baseAddress;
	// Data position in record.
	long dataPos;

	// Attempt to open file
	f.open( _filename.c_str(), ios::in );
	if( !f )
		throw new ErrorMsg( "Error opening HEX file for input!" );

	// Prepare
	baseAddress = 0;
	start = size;
	end = 0;

	// Parse records
	f >> hexLine; // Read one line.
	while( !f.eof() ) {
		// Process record according to type
		parseRecord( hexLine, &rec );

		switch( rec.type )
		{
		// Data record ?
		case 0x00 :
			// Copy data
			if( baseAddress + rec.offset + rec.length > size )
				throw new ErrorMsg( "HEX file defines data outside buffer limits! "
						"Make sure file does not contain data outside device "
						"memory limits. "
						"Line from file was: (" + hexLine + ")." );

			for( dataPos = 0; dataPos < rec.length; dataPos++ )
				data[ baseAddress + rec.offset + dataPos ] = rec.data[ dataPos ];

			//* Update byte usage
			if( baseAddress + rec.offset < start )
				start = baseAddress + rec.offset;

			if( baseAddress + rec.offset + rec.length - 1 > end )
				end = baseAddress + rec.offset + rec.length - 1;

			break;

		// Extended segment address record ?
		case 0x02 :
			baseAddress = (rec.data[0] << 8) | rec.data[1];
			baseAddress <<= 4;
			break;

		// Start segment address record ?
		case 0x03 :
			break; // Ignore it, since we have no influence on execution start address.

		// Extended linear address record ?
		case 0x04 :
			baseAddress = (rec.data[0] << 8) | rec.data[1];
			baseAddress <<= 16;
			break;

		// Start linear address record ?
		case 0x05 :
			break; // Ignore it, since we have no influence on exectuion start address.

		// End of file record ?
		case 0x01 :
			f.close();
			Util.progress( "\r\n" ); // Finish progress indicator.
			return;

		default:
			throw new ErrorMsg( "Unsupported HEX record format! "
					"Line from file was: (" + hexLine + ")." );
		}

		// Read next line.
		f >> hexLine;
	}

	// We should not end up here
	throw new ErrorMsg( "Premature end of file encountered! Make sure file "
			"contains an EOF-record." );
}

/** \brief Writes data to a HEX file
 *
 *  \param _filename String containing name of HEX file
 */
void HEXFile::writeFile( const string & _filename )
{
	ofstream f;
	// Temp record.
	HEXRecord rec;

	// Absolute data position.
	long baseAddress;
	// Offset from base address.
	long offset;
	// Position inside data record.
	long dataPos;

	enum
	{ 
		_first,
		_writing,
		_passed64k
	} status; // Write status, see usage below.

	// Attempt to create file
	f.open( _filename.c_str(), ios::out );
	if( !f )
		throw new ErrorMsg( "Error opening HEX file for output!" );

	// Prepare 
	status = _first;
	rec.data = new unsigned char[ 16 ]; // Use only 16 byte records.

	baseAddress = start & ~0xffff; // 64K aligned address.
	offset = start & 0xffff; // Offset from the aligned address.
	dataPos = 0;

	// Write first base address record to HEX file
	rec.length = 2;
	rec.offset = 0;
	rec.type = 0x02;
	rec.data[1] = 0x00;
	rec.data[0] = baseAddress >> 12; // Give 4k page index.
	writeRecord( f, &rec ); // Write the HEX record to file.


	// Write all bytes in used range
	do {
		// Put data into record
		rec.data[ dataPos ] = data[ baseAddress + offset + dataPos ];
		dataPos++;

		// Check if we need to write out the current data record
		if( offset + dataPos >= 0x10000 || // Reached 64k boundary?
				dataPos >= 16 || // Data record full?
				baseAddress + offset + dataPos > end ) { // End of used range reached?
			// Write current data record
			rec.length = dataPos;
			rec.offset = offset;
			rec.type = 0x00; // Data record.

			Util.progress( "#" ); // Advance progress indicator.
			writeRecord( f, &rec );

			offset += dataPos;
			dataPos = 0;
		}    

		// Check if we have passed a 64k boundary
		if( offset + dataPos >= 0x10000 ) {
			// Update address pointers
			offset -= 0x10000;
			baseAddress += 0x10000;

			// Write new base address record to HEX file 
			rec.length = 2;
			rec.offset = 0;
			rec.type = 0x02;
			rec.data[0] = baseAddress >> 12; // Give 4k page index.
			rec.data[1] = 0x00;

			writeRecord( f, &rec ); // Write the HEX record to file.
		}
	} while( baseAddress + offset + dataPos <= end );


	// Write EOF record
	rec.length = 0;
	rec.offset = 0;
	rec.type = 0x01;

	writeRecord( f, &rec );

	f.close();
	Util.progress( "\r\n" ); // Finish progress indicator.
}

/** \brief Set range for read and write operations
 *
 * It overrides the memory range indicators
 *
 *  \param _start Start address
 *  \param _end   End address
 */
void HEXFile::setUsedRange( long _start, long _end )
{
	if( _start < 0 || _end >= size || _start > _end )
		throw new ErrorMsg( "Invalid range! Start must be 0 or larger, end must be "
				"inside allowed memory range." );

	start = _start;
	end = _end;
}

/** \brief Sets entire data buffer to the desired value
 *
 *  \param value Value to be filled in buffer
 */
void HEXFile::clearAll( long value )
{
	for( long i = 0; i < size; i++ )
		data[i] = (unsigned char) (value & 0xff);
}

/** \brief Access method for data in the buffer
 *
 *  \param address Address from which data is needed
 *
 *  \return data at specified address
 */
long HEXFile::getData( long address )
{
	if( address < 0 || address >= size )
		throw new ErrorMsg( "Address outside legal range!" );

	return data[ address ];
}

/** \brief Access method for setting data in the buffer
 *
 *  \param address Address to which data is to be set
 *  \param value   Value to be set in buffer
 */
void HEXFile::setData( long address, long value )
{
	if( address < 0 || address >= size )
		throw new ErrorMsg( "Address outside legal range!" );

	data[ address ] = (unsigned char) (value & 0xff);
}
