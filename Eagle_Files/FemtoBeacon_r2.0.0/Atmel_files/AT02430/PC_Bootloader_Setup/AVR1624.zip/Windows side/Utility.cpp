/** \file
 *
 * \brief  AVR TWIGEN Utilities file
 *
 * This file is used for log and progress messages and for enabling silent
 * operation. 
 *
 * \par Application note:
 * AVR1624: Using ATxmega128A1 Xplain Kit as USB to TWI Bridge
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */
#include "Utility.hpp"

#include <iostream>
#include <fstream>
#include <stdlib.h>

// Global object
Utility Util;

/** \brief Constructor
 *
 * Initializes the internal log and progress status to enable both log and progress
 * messages.
 */
Utility::Utility() :
	noLog( false ),
	noProgress( false )
{
	// No code here
}

/** \brief Destructor
 *
 * Currently has no function. Just a placeholder for future extensions.
 */
Utility::~Utility()
{
	// No code here
}

/** \brief Prints messages
 *
 * Prints log-type messages to the screen if not muted
 *  \param txt String to be displayed
 */
void Utility::log( const string & txt )
{
	if( !noLog )
		cout << txt;
}

/** \brief Displays progress of operation
 *
 * Displays progress-type messages to the screen if not muted
 *  \param txt String to be displayed
 */
void Utility::progress( const string & txt )
{
	if( !noProgress )
		cout << txt;
}

/** \brief Converts hexadecimal string to a number
 *
 *  \param txt String to be converted
 *
 *  \return Number from hexdecimal string
 */
long Utility::convertHex( const string & txt )
{
	long result = 0;
	long digit;
	long i;

	if( txt.size() == 0 )
		throw new ErrorMsg( "Cannot convert zero-length hex-string to number!" );

	if( txt.size() > 8 )
		throw new ErrorMsg( "Hex conversion overflow! Too many hex digits in string." );


	for( i = 0; i < txt.size(); i++ ) {
		// Convert hex digit 
		if( txt[i] >= '0' && txt[i] <= '9' )
			digit = txt[i] - '0';
		else if( txt[i] >= 'a' && txt[i] <= 'f' )
			digit = txt[i] - 'a' + 10;
		else if( txt[i] >= 'A' && txt[i] <= 'F' )
			digit = txt[i] - 'A' + 10;
		else
			throw new ErrorMsg( "Invalid hex digit found!" );

		// Add digit as least significant 4 bits of result
		result = (result << 4) | digit;
	}

	return result;
}

/** \brief Converts number to string using specified radix.
 *
 *  \param num   Number to be converted
 *  \param radix Desired radix to be used for conversion
 *
 *  \return String from specified number
 */
string Utility::convertLong( long num, long radix )
{
	char buf[18];
	string res;

	itoa( num, buf, radix );
	res = buf;
	return res;
}

/** \brief Parses a specified path
 *
 *  \param parsePath Path which is to be parsed
 */
void Utility::parsePath( vector<string> & list )
{
	// Get environment variable and parse if it exists
	char * pathptr = getenv( "PATH" );
	if( pathptr != NULL && pathptr[0] != 0 ) {
		string path = pathptr;
		int pos;

		while( (pos = path.find_first_of( ";" )) < path.length() ) {
			list.push_back( path.substr( 0, pos ) );
			path.erase( 0, pos+1 );
		}

		// Last directory.
		list.push_back( path );
	}
}

/** \brief Checks whether a file exists
 *
 *  \param filename File whose existence is to be checked
 *
 *  \return Existence status
 */
bool Utility::fileExists( string filename )
{
	// Attempt to open file
	ifstream f;
	f.open( filename.c_str(), ios::in );
	if( !f ) {
		return false;
	} else {
		f.close();
		return true;
	}
}

/** \brief Saves specified string in a specified file
 *
 *  \param txt      String to be saved
 *  \param filename File in which string is to be saved
 */
void Utility::saveString( string txt, string filename )
{
	ofstream f;

	f.open( filename.c_str(), ios::out );
	if( !f )
		throw new ErrorMsg( "Error opening HEX file for output!" );

	f << txt;

	f.close();
}

/** \brief Gets registry value from specified path
 *
 * Retrieves value from Windows Registry Database
 *
 *  \param path  String containing Registry key path
 *  \param value String containing Key name
 *
 *  \return String containing retrived registry value
 */
#ifndef NOREGISTRY
string Utility::getRegistryValue( const string & path, const string & value )
{
	// Code modified from MSDN
	const long BUFSIZE=1000;
	string result;
	HKEY hKey;
	char szAVRPath[BUFSIZE];
	DWORD dwBufLen=BUFSIZE;
	LONG lRet;

	// Open key
	lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, path.c_str(), 0, KEY_QUERY_VALUE, &hKey );
	if( lRet != ERROR_SUCCESS )
		throw new ErrorMsg( "Error when opening registry key: (" + path + ")!" );

	// Get value
	lRet = RegQueryValueEx( hKey, value.c_str(), NULL, NULL, (LPBYTE) szAVRPath, &dwBufLen);
	if( (lRet != ERROR_SUCCESS) || (dwBufLen > BUFSIZE) )
		throw new ErrorMsg( "Error when reading key value: (" + value + ")!" );

	// Clean up and return result
	RegCloseKey( hKey );
	result = szAVRPath;
	return result;
}
#endif
