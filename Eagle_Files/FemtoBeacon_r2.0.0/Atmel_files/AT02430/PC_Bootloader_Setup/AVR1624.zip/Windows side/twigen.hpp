/** \file *********************************************************************
 *
 * \brief  AVR TWIGEN Command-line parser header file.
 *
 * This file contains the function prototypes and class definitions
 * for various parameters for the AVR TWIGEN Command-line parser.
 *
 * \par Application note:
 * AVR1624: Using ATxmega128A1 Xplain Kit as USB to TWI Bridge
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */
#ifndef TWIGEN_HPP
#define TWIGEN_HPP

using namespace std;

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include "HEXParser.hpp"

/** \brief Class for parsing command-line parameters and processing
 */
class twigen
{
	public:
		string inputFileFlash;

	public:
		twigen(); // Constructor

		int parseArguments(int, char **);
		int checkArguments();
		void displayBytes(unsigned short, unsigned char *);
		int getAck();
		int Ack();
		int executeQueue();
		int Write(unsigned char, unsigned char *, unsigned short, unsigned char *);
		int Read(unsigned char, unsigned char *, unsigned short, unsigned char *);
		int eraseFlash();
};

#endif
