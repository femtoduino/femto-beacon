/** \file
 *
 * \brief  AVR TWIGEN Command-line parser file
 *
 * This file implements parsing through the command-line parameters and
 * processes them accordingly. It also shows how to program a HEX file 
 * to the device.
 *
 * \par Application note:
 * AVR1624: Using ATxmega128A1 Xplain Kit as USB to TWI Bridge
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

using namespace std;

/*! Include files */
#include <stdio.h>
#include <windows.h>
#include "commport.hpp"
#include "twigen.hpp"
#include <string>

#define VERSION     "1.4"

#define BUFFER_SIZE	512

#define NACK	0x5A
#define ACK 	0xA5

#define QUEUE		0xBA
#define QUEUE_EXEC	0xB5
#define QUEUE_SIZE 	50

#define WRITE   0xC0
#define READ    0xCF
// Page size in words
#define PAGE_SIZE 256

// delay for queue'd commands.  defaults to zero
unsigned short g_usDelay = 0;

// address buffer
unsigned char g_ucAddressBuffer[8];

// write buffer
unsigned char g_ucWriteBuffer[BUFFER_SIZE];

// read buffer
unsigned char g_ucReadBuffer[BUFFER_SIZE];

// slave address, default to 0x66
unsigned char g_ucSlaveAddr = 0x66;

// check necessary
unsigned char g_ucCheck = 0;

// verify necessary
unsigned char g_ucVerify = 0;

// write byte operation
unsigned char g_ucWrite = 0;

// byte count
unsigned short g_usByteCnt = 0;

// read operation
unsigned char g_ucRead = 0;

// queue the operation
unsigned char g_ucQueue = 0;

// retry the queued operation
unsigned char g_ucRetry = 1;

// queue execute operation
unsigned char g_ucQueueExec = 0;

// address size in bytes.  defaults to 0.  valid 1-4
unsigned char g_ucAddrSize = 0;

// Input HEX file given
unsigned char g_ucInputFile = 0;

// Erase operation
unsigned char g_ucErase = 0;

// Write HEX operation
unsigned int g_ucWriteHex = 0;

// com port name, defaults to COM1
char g_pcCommPortName[32] =
{
    "\\\\.\\COM1"
};

// COM port HANDLE
HANDLE g_CommPortHandle;

static char const UsageString[] =
{
"\n"
"Version " VERSION "\n"
"Usage examples:\n"
"Erases and then programs the specified hex file at triple byte sub\n"
"address 0x000000 to slave 0x55 and COM port 14\n"
"twigen -e -iLEDCHASER.hex -a 3 0x00 0x00 0x00 -s 0x55 -p 14\n"
"\n"
"Erases flash memory of slave 0x55 and COM port 14\n"
"twigen -e -a 3 0x00 0x00 0x00 -s 0x55 -p 14\n"
"\n"
"Read 0x20 bytes from slave 0x5E using a single byte sub address of\n"
"0x00 and COM port 26.\n"
"twigen -r 0x20 -a 1 0x00 -s 0x5E -p 26\n"
"\n"
"Read 0x30 bytes from slave 0x52 using a double byte sub address of\n"
"0x0000 and COM port 26.\n"
"twigen -r 0x30 -a 2 0x00 0x00 -s 0x52 -p 26\n"
"\n"
"Write 1 byte of value 0x11 to slave 0x5E using a single byte sub\n"
"address of 0x07 and COM port 26.\n"
"twigen -w 1 0x11 -a 1 0x07 -s 0x5E -p 26\n"
"\n"
"Write 2 bytes of value 0x55AA to slave 0x52 using a double byte sub\n"
"address of 0x0010 and COM port 26.\n"
"twigen -w 2 0x55 0xAA -a 2 0x00 0x10 -s 0x52 -p 26\n"
"\n"
"\n"
"Descriptions:\n"
"-e\n"
"    Erases device.\n"
"-i[infile]\n"
"    Program flash with specified hex input file.\n"
"    The file format is Intel Extended HEX.\n"
"-r [num bytes]\n"
"    Read the number of bytes specified.\n"
"-w [num bytes] [byte0] [byte1] ...\n"
"    Write the number of bytes specified.  The data is defined by\n"
"    byte0, byte1, and so on.\n"
"-a [address size in bytes] [address byte0] [address byte1] ...\n"
"    Use the sub address size specified.  The address is defined by\n"
"    address byte0, address byte1, and so on.\n"
"-x\n"
"    Execute the queued commands.\n" 
"-v\n"
"    Verify the specified operation after performing the operation.\n"
"-c\n"
"    Verify the specified operation without performing the operation.\n"
"-s [slave address]\n"
"    Specifies the I2C slave address.\n\n"
"-p [COM port]\n"
"    Specifies the COM port on the PC to use to communicate to the Xplain\n"
"    board.\n"
"-q\n"
"    Queues up the specified command. The queued commands can be executed by\n"
"    executing the -x command.\n"
"-d [delay]\n"
"    Specifies the delay in milliseconds for the queued commands. This delay\n"
"    take place prior to executing the command.\n"
"-n\n"
"    Specifies to not retry the transaction if it is not acknowledged by the\n"
"    slave.  This option is only valid for a queued command.  Each command\n"
"    will retry by default if this option is not specified.\n" 
"\n"
"Rules:\n"
"-- Only one operation can be specified at once.\n"
"-- -v and -c can not be specified for the same operation.\n"
"-- -v or -c cannot be used with a zero byte write or any size read.\n"
"-- -n can only be specified for a queued command\n"
"\n"
"Version " VERSION "\n"
};

/** \brief Constructor of class twigen.
 *
 *  Erases the string holding the name of input HEX file to be programmed.
 *
 */
twigen::twigen()
{
	inputFileFlash.erase();
}

/** \brief Parses the command-line arguments.
 *
 *  Parses through the command-line arguments and sets flags for corresponding
 *  operations to be performed.
 *
 *  \param argc         Number of arguments.
 *  \param argv         Pointer to the arguments passed.
 *
 *  \return Status - Success or Failure
 */
int twigen::parseArguments(int argc, char **argv)
{
	unsigned long ulArgCount;
	unsigned char ucCnt;
	unsigned short usCnt;
	char * param;

	// The first argument is 'twigen'
	for(ulArgCount = 1; ulArgCount < argc; ulArgCount++) {
		param = argv[ulArgCount];

		// Check to make sure that the argument is preceded by a '-'
		if(argv[ulArgCount][0] != '-') {
			printf("ERROR: Invalid arguments!  \n");
			return(-2);        
		}

		// Switch based on the option used
		switch(argv[ulArgCount][1])
		{
		// Display Help
		case '?':
		case 'h':
			return(-1);
			break;

		// Send command to program specified HEX file
		case 'i':
			g_ucInputFile = 1;
			inputFileFlash.assign( param + 2 );
			break;

		// Send command to erase the device
		case 'e':
			g_ucErase = 1;
			g_ucAddrSize = 3;
			break;

		// Verify without performing the operation
		case 'c':
			g_ucCheck = 1;
			break;

		// Verify after performing the operation
		case 'v':
			g_ucVerify = 1;
			break;

		// Queue up the specified command
		case 'q':
			g_ucQueue = 1;
			break;

		// Execute the queued command
		case 'x':
			g_ucQueueExec = 1;
			break;

		// Do not retry
		case 'n':
			g_ucRetry = 0;
			break;

		// COM port to be used
		case 'p':
			sprintf(g_pcCommPortName, "\\\\.\\COM%s", argv[++ulArgCount]);
			break;

		// Address bytes
		case 'a':
			g_ucAddrSize = strtoul(argv[++ulArgCount], 0, 0);
			if(g_ucAddrSize > 4) {
				printf("ERROR: Address size cannot be larger than 4 bytes!\n");
				return(-1);	
			}
			for(ucCnt = 0; ucCnt < g_ucAddrSize; ucCnt++) {
				g_ucAddressBuffer[ucCnt] = strtoul(argv[++ulArgCount], 0, 0);
			}
			break;

		// Write bytes specified
		case 'w':
			g_usByteCnt = strtoul(argv[++ulArgCount], 0, 0);
			if(g_usByteCnt > BUFFER_SIZE) {
				printf("ERROR: Byte count cannot be larger than %d!\n", BUFFER_SIZE);
				return(-1);	
			}
			// Initialize Write Buffer with 0x00 
			for(usCnt = 0; usCnt < g_usByteCnt; usCnt++) {
				g_ucWriteBuffer[usCnt] = strtoul(argv[++ulArgCount], 0, 0);
			}
			g_ucWrite = 1;
			break;

		// Read specified number of bytes
		case 'r':
			g_usByteCnt = strtoul(argv[++ulArgCount], 0, 0);
			if(g_usByteCnt > BUFFER_SIZE) {
				printf("ERROR: Byte count cannot be larger than %d!\n", BUFFER_SIZE);
				return(-1);	
			}
			g_ucRead = 1;
			break;

		// TWI Slave address
		case 's':
			g_ucSlaveAddr = strtoul(argv[++ulArgCount], 0, 0);
			break;

		// Delay in milliseconds for queued operations
		case 'd':
			g_usDelay = strtoul(argv[++ulArgCount], 0, 0);	
			break;

		// Invalid argument
		default:
			printf("ERROR: Invalid arguments!\n");
			return(-1);
		}  
	}
	return(0);
}

/** \brief Checks necessary arguments
 *
 * Checks operations to be performed and whether it follows the rules.
 *
 *  \return Status - Success or Failure
 */
int twigen::checkArguments(void)
{
	unsigned char ucOpCnt;
	unsigned short usCnt;

	ucOpCnt = 0;

	if(g_ucWrite)
		ucOpCnt++;
	if(g_ucRead)
		ucOpCnt++;
	if(g_ucQueueExec)
		ucOpCnt++;
	if(g_ucInputFile)
		ucOpCnt++;
	if(g_ucErase)
		ucOpCnt++;
	if(ucOpCnt == 0) {
		printf("ERROR: No operations specified.\n");
		return(-1);
	}
	if(ucOpCnt > 1) {
		if(!(g_ucInputFile && g_ucErase)) {
			printf("ERROR: More than one operation specified.\n");
			return(-1);
		}
	}

	if(g_ucVerify && g_ucCheck) {
		printf("ERROR: Options -c and -v cannot both be specified.\n");
		return(-1);
	}

	if(g_ucWrite && (g_usByteCnt == 0) && g_ucVerify) {
		printf("ERROR: Option -v is not valid with a zero byte write.\n");
		return(-1);
	}

	if(g_ucWrite && (g_usByteCnt == 0) && g_ucCheck) {
		printf("ERROR: Option -c is not valid with a zero byte write.\n");
		return(-1);
	}

	if(g_ucRead && g_ucVerify) {
		printf("ERROR: Option -v is not valid with a read operation.\n");
		return(-1);
	}

	if(g_ucRead && g_ucCheck) {
		printf("ERROR: Option -c is not valid with a read operation.\n");
		return(-1);
	}

	if(!g_ucRetry && !g_ucQueue) {
		printf("ERROR: Option -n is only valid when using -q.\n");
		return(-1);
	}

	if(g_ucQueue) {
		if(g_ucVerify) {
			printf("ERROR: Option -v cannot be used with an operation to be queued.\n");
			return(-1);
		}
		if(g_ucCheck) {
			printf("ERROR: Option -v cannot be used with an operation to be queued.\n");
			return(-1);
		}
	}

	if(((g_ucAddrSize < 1) || (g_ucAddrSize > 4)) && !g_ucQueueExec) {
		printf("ERROR: Illegal address size!\n");
		return(-1); 
	}

	return(0);
}

/** \brief Displays the requested bytes of data.
 *
 *  \param usByteCnt Number of bytes to be displayed.
 *  \param Pointer to the string to be displayed.
 */
void twigen::displayBytes(unsigned short usByteCnt,
             unsigned char *pucBuffer)
{
	unsigned short usCnt;

	for(usCnt = 0; usCnt < usByteCnt; usCnt++) {
		if(!(usCnt % 8)) {
			printf("\n");
		}
		printf("%02X  ", pucBuffer[usCnt]);
	}

	printf("\n");
}

/** \brief Gets acknowledge byte
 *
 * From the COM port gets acknowledge byte and returns 0 when successful
 *
 *  \return Status - Success or Failure
 */
int twigen::getAck(void)
{
	unsigned char ucData;

	// get ACK
	if(CommPortRx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}
	// check that the byte received was the ACK
	if(ucData != ACK) {
		return(-1);
	}

	return(0);
}

/** \brief Sends acknowledge byte
 *
 * Sends acknowledgement over specified COM port
 *
 *  \return Status - Success or Failure
 */
int twigen::Ack(void)
{
	unsigned char ucData;

	ucData = ACK;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}
	return(0);
}

/** \brief Executes the queued commands.
 *
 *  Processes and executes the queued commands with the delay specified
 *
 *  \return Status - Success or Failure
 */
int twigen::executeQueue(void)
{
	unsigned char ucData;
	unsigned char ucQueueCnt;
	unsigned char ucCnt;
	unsigned short usOpSize;
	unsigned char ucAddrSize;
	unsigned char ucSlaveAddr;
	unsigned char ucCmd;
	unsigned char ucCnt1;
	unsigned short usCnt;
	unsigned char ucSuccess;
	unsigned short usDelay;
	unsigned char ucAddr[4];

	// send the queue execute command
	ucData = QUEUE_EXEC;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}

	// get ACK
	if(getAck()) {
		return(-1);
	}

	// get the number of commands in the queue
	if(CommPortRx(&g_CommPortHandle, &ucQueueCnt, 1) == FALSE) {
		return(-1);
	}

	printf("Executing %d commands:\n\n", ucQueueCnt);

	// get the total delay time of the queue
	if(CommPortRx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}
	usDelay = ucData;
	usDelay = usDelay << 8;

	if(CommPortRx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}
	usDelay |= ucData;

	// sleep for the delay time in ms
	Sleep(usDelay);

	// process the commands that executed
	for(ucCnt = 0; ucCnt < ucQueueCnt; ucCnt++) {
		//get the success or failure
		if(CommPortRx(&g_CommPortHandle, &ucSuccess, 1) == FALSE) {
		 	return(-1);
		}

		// get the delay for the command
		if(CommPortRx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}
		usDelay = ucData;

		usDelay = usDelay << 8;

		if(CommPortRx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}
		usDelay |= ucData;

		//get the size
		if(CommPortRx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}

		usOpSize = ucData;

		usOpSize = usOpSize << 8;

		if(CommPortRx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}

		usOpSize |= ucData;

		// get the slave address
		if(CommPortRx(&g_CommPortHandle, &ucSlaveAddr, 1) == FALSE) {
			return(-1);
		}

		// get the address size
		if(CommPortRx(&g_CommPortHandle, &ucAddrSize, 1) == FALSE) {
			return(-1);
		}

		// get the address
		for(ucCnt1 = 0; ucCnt1 < ucAddrSize; ucCnt1++) {
			if(CommPortRx(&g_CommPortHandle, &ucAddr[ucCnt1], 1) == FALSE) {
				return(-1);
			}
		}

		// get the command
		if(CommPortRx(&g_CommPortHandle, &ucCmd, 1) == FALSE) {
			return(-1);
		}

		// switch based on the command
		switch(ucCmd)
		{
		case WRITE:
			if(ucSuccess) {
				//get the data
				for(usCnt = 0; usCnt < usOpSize; usCnt++) {
					//get the data
					if(CommPortRx(&g_CommPortHandle, &g_ucReadBuffer[usCnt], 1) == FALSE) {
						return(-1);
					}
				}

				printf("Write of size %d to slave 0x%02X with %d ms delay.\n", usOpSize, ucSlaveAddr, usDelay);
				switch(ucAddrSize)
				{
				case 1:
					printf("Addr:\t0x%02X\n", ucAddr[0]);
					break;

				case 2:
					printf("Addr:\t0x%02X 0x%02X\n", ucAddr[0], ucAddr[1]);
					break;

				case 3:
					printf("Addr:\t0x%02X 0x%02X 0x%02X\n", ucAddr[0], ucAddr[1], ucAddr[3]);
					break;

				case 4:
					printf("Addr:\t0x%02X 0x%02X 0x%02X 0x%02X\n", ucAddr[0], ucAddr[1], ucAddr[3], ucAddr[4]);
					break;
				}
				printf("Data:\t");
				for(usCnt = 0; usCnt < usOpSize; usCnt++) {
					printf("0x%02X  ", g_ucReadBuffer[usCnt]);
					if(!((usCnt + 1) % 8)) {
						printf("\n\t");
					}
				}

				printf("\n");
			}
			else {
				switch(ucAddrSize)
				{
				case 1:
					printf("ERROR: Write of size %d to slave 0x%02X at address 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0]);
					break;

				case 2:
					printf("ERROR: Write of size %d to slave 0x%02X 0x%02X at address 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0], ucAddr[1]);
					break;

				case 3:
					printf("ERROR: Write of size %d to slave 0x%02X 0x%02X 0x%02X at address 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0], ucAddr[1], ucAddr[2]);
					break;

				case 4:
					printf("ERROR: Write of size %d to slave 0x%02X 0x%02X 0x%02X 0x%02X at address 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0], ucAddr[1], ucAddr[2], ucAddr[3]);
					break;
				}
			}
			break;

		case READ:
			if(ucSuccess) {
				for(usCnt = 0; usCnt < usOpSize; usCnt++) {
					// get the data
					if(CommPortRx(&g_CommPortHandle, &g_ucReadBuffer[usCnt], 1) == FALSE) {
						return(-1);
					}
 				}

				printf("Read of size %d from slave 0x%02X with %d ms delay.\n", usOpSize, ucSlaveAddr, usDelay);
				switch(ucAddrSize)
				{
				case 1:
					printf("Addr:\t0x%02X\n", ucAddr[0]);
					break;

				case 2:
					printf("Addr:\t0x%02X 0x%02X\n", ucAddr[0], ucAddr[1]);
					break;

				case 3:
					printf("Addr:\t0x%02X 0x%02X 0x%02X\n", ucAddr[0], ucAddr[1], ucAddr[3]);
					break;

				case 4:
					printf("Addr:\t0x%02X 0x%02X 0x%02X 0x%02X\n", ucAddr[0], ucAddr[1], ucAddr[3], ucAddr[4]);
					break;
				}

				printf("Data:\t");
				for(usCnt = 0; usCnt < usOpSize; usCnt++) {
					printf("0x%02X  ", g_ucReadBuffer[usCnt]);
					if(!((usCnt + 1) % 8)) {
						printf("\n\t");
					}
				}

				printf("\n");
			}
			else {
				switch(ucAddrSize)
				{
				case 1:
					printf("ERROR: Read of size %d from slave 0x%02X at address 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0]);
					break;

				case 2:
					printf("ERROR: Read of size %d from slave 0x%04X at address 0x%02X 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0], ucAddr[1]);
					break;

				case 3:
					printf("ERROR: Read of size %d from slave 0x%06X at address 0x%02X 0x%02X 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0], ucAddr[1], ucAddr[2]);
					break;

				case 4:
					printf("ERROR: Read of size %d from slave 0x%08X at address 0x%02X 0x%02X 0x%02X 0x%02X failed.\n", usOpSize, ucSlaveAddr, ucAddr[0], ucAddr[1], ucAddr[2], ucAddr[3]);
					break;
				}
			}
			break;

		default:
			break;
		}

		// send the acknowledge that we received all of the data
		ucData = ACK;
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}

		printf("\n");
	}

	return(0);
}

/** \brief Writes specified data
 * 
 * Writes the specified data to the specified slave and at specified address
 *
 *  \param ucSlaveAddr   The TWI Slave address
 *  \param pucAddrBuffer Pointer to the buffer containing address where data is
 *                       to be written
 *  \param usByteCnt     Number of bytes to be written
 *  \param pucBuffer     Pointer to the buffer containing data to be written
 *
 *  \return Status - Success or Failure
 */
int twigen::Write(unsigned char ucSlaveAddr, unsigned char *pucAddrBuffer, unsigned short usByteCnt, unsigned char *pucBuffer)
{
 	unsigned char ucData;
	unsigned char ucCnt;
	unsigned short usCnt;

	// if it is a command to be queue'd, send the queue command
	if(g_ucQueue) {
		// send queue command
		ucData = QUEUE;
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}

		// get ACK
		if(getAck()) {
			return(-1);
		}
	}

	// send page write command
	ucData = WRITE;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}

	// get ACK
	if(getAck()) {
		return(-1);
	}

	// send the size //dcwFLAG need to fix for DoubleByte
	ucData = usByteCnt >> 8; // Send MSB
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}
	ucData = usByteCnt; // Send LSB: Truncate MSB via typecast to 8bit variable
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}

	// send slave address
	ucData = ucSlaveAddr;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}

	// send the address size
	ucData = g_ucAddrSize;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		return(-1);
	}

	for(ucCnt = 0; ucCnt < g_ucAddrSize; ucCnt++) {
		// send the address
		ucData = pucAddrBuffer[ucCnt];
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}
	}

	for(usCnt = 0; usCnt < usByteCnt; usCnt++) {
		// send the 8bit data
		ucData = pucBuffer[usCnt];
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}
	}

	if(g_ucQueue) {
		// send the 16bit delay, MSBs first
		ucData = (g_usDelay & 0xFF00) >> 8;
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}

		ucData = (g_usDelay & 0x00FF);
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			return(-1);
		}

		// send the retry option
		if(CommPortTx(&g_CommPortHandle, &g_ucRetry, 1) == FALSE) {
			return(-1);
		}
	}

	// get ACK after the write
	if(getAck()) {
		return(-1);
	}

	return(0);
}

/** \brief Reads specified number of bytes
 * 
 * Writes the specified number of bytes from specified slave and at specified
 * address
 *
 *  \param ucSlaveAddr   The TWI Slave address
 *  \param pucAddrBuffer Pointer to the buffer containing address where data 
 *                       to be read
 *  \param usByteCnt     Number of bytes to be read
 *  \param pucBuffer     Pointer to the buffer containing data read
 *
 *  \return Status - Success or Failure
 */
int twigen::Read(unsigned char ucSlaveAddr, unsigned char *pucAddrBuffer, unsigned short usByteCnt, unsigned char *pucBuffer)
{
	unsigned char ucData;
	unsigned short usData;
	unsigned char ucCnt;
	unsigned short usCnt;

	// if it is a command to be queue'd, send the message
	if(g_ucQueue) {
		// send queue command
		ucData = QUEUE;
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			printf("ERROR: Queue Read Operation Failed!\n");
			return(-1);
		}

		// get ACK
		if(getAck()) {
			printf("ERROR: Queue Read Operation ACK Failed!\n");
			return(-1);
		}
	}

	// send read page command
	ucData = READ;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		printf("ERROR: Send Read Page Operation Failed!\n");
		return(-1);
	}

	// get ACK
	if(getAck()) {
		printf("ERROR: Read Page Operation ACK Failed!\n");
		return(-1);
	}

	// send the size //dcwFLAG need to fix to send DoubleByte
	ucData = usByteCnt >> 8; // Send MSB
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		printf("ERROR: Read Page Operation Size Send MSB Failed!\n");
		return(-1);
	}
	ucData = usByteCnt; // Send LSB: truncate MSB to send Only LSB
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		printf("ERROR: Read Page Operation Size Send LSB Failed!\n");
		return(-1);
	}

	// send slave address
	ucData = ucSlaveAddr;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		printf("ERROR: Read Page Operation Slave Address Send Failed!\n");
		return(-1);
	}

	// send the address size
	ucData = g_ucAddrSize;
	if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
		printf("ERROR: Read Page Operation Slave Address Size Send Failed!\n");
		return(-1);
	}

	// send the address bytes
	for(ucCnt = 0; ucCnt < g_ucAddrSize; ucCnt++) {
		//send the address
		ucData = pucAddrBuffer[ucCnt];
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			printf("ERROR: Read Page Operation SubAddress Send Failed!\n");
			return(-1);
		}
	}

	if(g_ucQueue) {
		// send the 16bit delay, MSBs first
		ucData = (g_usDelay & 0xFF00) >> 8;
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			printf("ERROR: Read Page Operation Delay Send MSB Failed!\n");
			return(-1);
		}

		ucData = (g_usDelay & 0x00FF);
		if(CommPortTx(&g_CommPortHandle, &ucData, 1) == FALSE) {
			printf("ERROR: Read Page Operation Delay Send LSB Failed!\n");
			return(-1);
		}

		//send the retry option
		if(CommPortTx(&g_CommPortHandle, &g_ucRetry, 1) == FALSE) {
			printf("ERROR: Read Page Operation RetryOption Send Failed!\n");
			return(-1);
		}
	}

	// get ACK after the read
	if(getAck()) {
		printf("ERROR: Read Page Operation ACK non-Queued Failed!\n");
		return(-1);
	}

	if(!g_ucQueue) {
		for(usCnt = 0; usCnt < usByteCnt; usCnt++) {
			//get the data
			if(CommPortRx(&g_CommPortHandle, &pucBuffer[usCnt], 1) == FALSE) {
				printf("ERROR: Read Page Operation Read Byte %d Failed!\n",usCnt+1);
				return(-1);
			}
		}
	}

	return(0);
}

/** \brief Manage parsing command-line inputs and their processing
 *
 *  \return Status - Success or Failure
*/
int main(int argc, char **argv)
{
	FILE *hFile;
	twigen i;
	HEXFile * hex;

	unsigned char ucCnt;
	unsigned short usCnt;
	unsigned char ucTxData;
	unsigned char ucRxData;
	unsigned long flashSize = 0x1ffff,temp;
	unsigned char tempAddressBuffer[8];
	bool Write_Pending = false;
	long address = 0;

	setbuf(stdout, 0);

	printf("twigen Running!\n");

	// Get any arguments that were passed in.
	if(i.parseArguments(argc, argv)) {
		printf("%s", UsageString);
		return(-1);
	}

	// Check the arguments
	if(i.checkArguments()) {
		return(-1);
	}

	// Open the COM port at 9600
	if(CommPortOpen(&g_CommPortHandle, g_pcCommPortName) == FALSE) {
		printf("ERROR: Failed to open the COM port: %s\n", g_pcCommPortName);
		CommPortClose(&g_CommPortHandle);
		return(-1);
	}

	// Initialize the COM port with 9600 baud rate
	if(CommPortInit(&g_CommPortHandle, 9600, 2) == FALSE) {
		printf("ERROR: Failed to initialize the COM port: %s\n", g_pcCommPortName);
		CommPortClose(&g_CommPortHandle);
		return(-1);
	}

	// is it byte write operation?
	if(g_ucWrite) {
		if(!g_ucCheck) {
			if(i.Write(g_ucSlaveAddr, &g_ucAddressBuffer[0], g_usByteCnt, &g_ucWriteBuffer[0])) {
				printf("ERROR: Write operation failed!\n");
				CommPortClose(&g_CommPortHandle);
				return(-1);
			}
			if(g_ucQueue) {
				printf("Write operation queued!\n");
			}
			else {
				printf("Write operation complete!\n");
			}
		}
		// both -c and -v cannot be specified. This is checked by CheckArgs()
		if(g_ucCheck || g_ucVerify) {
			if(i.Read(g_ucSlaveAddr, &g_ucAddressBuffer[0], g_usByteCnt, &g_ucReadBuffer[0])) {
				if(g_ucVerify) {
					printf("ERROR: Read operation to perform verify failed!\n");
				}
				else {
					printf("ERROR: Read operation to perform check failed!\n");
				}
				CommPortClose(&g_CommPortHandle);
				return(-1);	
			}
			for(usCnt = 0; usCnt < g_usByteCnt; usCnt++) {
				if(g_ucReadBuffer[usCnt] != g_ucWriteBuffer[usCnt]) {
					if(g_ucVerify) {
						printf("ERROR: Write verify failed!\n");
					}
					else {
						printf("ERROR: Write check failed!\n");	
					}
					CommPortClose(&g_CommPortHandle);
					return(-1);	
				}
			}

			if(g_ucVerify) {
				printf("Write verify passed!\n");
			}
			else {
				printf("Write check passed!\n");
			}
		}

		CommPortClose(&g_CommPortHandle);
		return(0);
	}

	// is it a read operation
	else if(g_ucRead) {
		if(i.Read(g_ucSlaveAddr, &g_ucAddressBuffer[0], g_usByteCnt, &g_ucReadBuffer[0])) {
			printf("ERROR: Read operation failed!\n");
			i.displayBytes(g_usByteCnt, &g_ucReadBuffer[0]);
			CommPortClose(&g_CommPortHandle);
			return(-1);
		}
		if(g_ucQueue) {
			printf("Read operation queued!\n");
		}
		else {
			printf("Read operation complete!\n");
			// display the data
			i.displayBytes(g_usByteCnt, &g_ucReadBuffer[0]);
		}

		CommPortClose(&g_CommPortHandle);
		return(0);
	}

	else if(g_ucQueueExec) {
		if(i.executeQueue()) {
			printf("ERROR: Execution of queue failed!\n");
		}
		else {
			printf("Execution of queue complete!\n");
		}
		CommPortClose(&g_CommPortHandle);
		return(0);
	}

	else if(g_ucInputFile) {
		long check;
		int page_full=0;
		int empty = 0, page_count = 0;                   

		tempAddressBuffer[0] = 0x00;
		tempAddressBuffer[1] = 0x00;
		tempAddressBuffer[2] = 0x00;                                            
		g_usByteCnt = 1;                 
		g_ucWriteBuffer[0] = 0x50;
		if(i.Write(g_ucSlaveAddr, &tempAddressBuffer[0], g_usByteCnt, &g_ucWriteBuffer[0])) {
			printf("\nERROR: Failed entering Programming Mode \n ");
			CommPortClose(&g_CommPortHandle);
			return(-1);
		}

		if(g_ucErase) {
			printf("\nErasing...");
			i.eraseFlash();
			printf("\nErasing Complete!");
		} 

		// Check that filename has been specified
		if( (i.inputFileFlash).size() == 0 )
			printf( "\nCannot program or verify Flash without input file specified!" );

		// Prepare the file
		hex = new HEXFile( flashSize );

		// Fill if wanted
		hex->clearAll( 0xff );

		temp = hex->getSize();                 

		// Read file
		Util.log( "\nReading HEX input file for flash operations...\r" );
		hex->readFile( (i.inputFileFlash) );

		g_ucWriteHex = (temp+1)/PAGE_SIZE;

		for(int j = 0; j < g_ucWriteHex; j++) {
			page_count++;
			for (int k = 0 + (j * PAGE_SIZE); k < PAGE_SIZE + (j * PAGE_SIZE); k++) {
				if(hex->getData(k)== 255) {
					empty++;
				}
			}
			if(empty > (PAGE_SIZE - (PAGE_SIZE/16))) {
				break;
			}
			else
				empty = 0;
		}

		// Program new Flash contents?
		// Program data
		printf( "\nProgramming Flash contents...\r\n" );

		for(int j = 0; j < 4; j++)
			tempAddressBuffer[j] = g_ucAddressBuffer[j];

		while(page_count && Write_Pending==false) {
			Write_Pending = true;

			check = (tempAddressBuffer[3]);
			check = (check<<8) | (tempAddressBuffer[2]);
			check = (check<<8) | (tempAddressBuffer[1]);
			check = (check<<8) | (tempAddressBuffer[0]);

			g_usByteCnt = PAGE_SIZE + 1;
			g_ucWriteBuffer[0] = 0x44;

			printf("#");
			for (int j = 1; j < (PAGE_SIZE + 1); j++) {
				g_ucWriteBuffer[j] = hex->getData(address);
				address++;
			}

			if(i.Write(g_ucSlaveAddr, &tempAddressBuffer[0], g_usByteCnt, &g_ucWriteBuffer[0])) {
				printf("\nERROR: Write operation failed! (Sending Page %d)", page_count);
				CommPortClose(&g_CommPortHandle);
				return(-1);
			}
			page_count--;

			if(page_full==0) {
				page_full=1;
				Write_Pending = false;
			}
			else {
				page_full=0;
				check = check + (2*PAGE_SIZE);
				unsigned char temp = (unsigned char)(Write_Pending);

				i.Read(g_ucSlaveAddr, &tempAddressBuffer[0], 1, &temp);

				Write_Pending = (bool)(temp);
			}

			tempAddressBuffer[0] = (char)(check);
			tempAddressBuffer[1] = (char)(check>>8);
			tempAddressBuffer[2] = (char)(check>>16);
			tempAddressBuffer[3] = (char)(check>>24);
		}

		tempAddressBuffer[0] = 0x00;
		tempAddressBuffer[1] = 0x00;
		tempAddressBuffer[2] = 0x00;                                            
		g_usByteCnt = 1;                 
		g_ucWriteBuffer[0] = 0x58;
		if(i.Write(g_ucSlaveAddr, &tempAddressBuffer[0], g_usByteCnt, &g_ucWriteBuffer[0])) {
			printf("\nERROR: Failed exiting Programming Mode");
			CommPortClose(&g_CommPortHandle);
			return(-1);
		}           
		printf("\nProgramming Complete!");
		return(0);
	}

	else if(g_ucErase) {
		tempAddressBuffer[0] = 0x00;
		tempAddressBuffer[1] = 0x00;
		tempAddressBuffer[2] = 0x00;                                            
		g_usByteCnt = 1;   

		printf("\nErasing...");
		g_ucWriteBuffer[0] = 0x50;
		if(i.Write(g_ucSlaveAddr, &tempAddressBuffer[0], g_usByteCnt, &g_ucWriteBuffer[0])) {
			printf("ERROR: Failed Entering Programming Mode for Erasing \n ");
			CommPortClose(&g_CommPortHandle);
			return(-1);
		}
		i.eraseFlash();
		g_ucWriteBuffer[0] = 0x58;
		if(i.Write(g_ucSlaveAddr, &tempAddressBuffer[0], g_usByteCnt, &g_ucWriteBuffer[0])) {
			printf("ERROR: Failed Exiting Programming Mode after Erasing \n ");
			CommPortClose(&g_CommPortHandle);
			return(-1);
		}
		printf("\nComplete!");
		return(0);
	}

	CommPortClose(&g_CommPortHandle);
	return(0); 
}
/** \brief Erases the flash memory of Slave
 * 
 * Issues commands to erase the flash memory of Slave
 *
 *  \return Status - Success or Failure
 */
int twigen::eraseFlash(void)
{
	unsigned char tempAddressBuffer[8];
	twigen i;

	tempAddressBuffer[0] = 0x00;
	tempAddressBuffer[1] = 0x00;
	tempAddressBuffer[2] = 0x00;                                            
	g_usByteCnt = 1;   

	g_ucWriteBuffer[0] = 0x45;
	if(i.Write(g_ucSlaveAddr, &tempAddressBuffer[0], g_usByteCnt, &g_ucWriteBuffer[0])) {
		printf("ERROR: Failed Erasing Device \n ");
		CommPortClose(&g_CommPortHandle);
		return(-1);
	}
	return(0);
}
