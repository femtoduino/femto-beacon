/** \file
 *
 * \brief  AVR TWIGEN HEX Parser Header file
 *
 * This file contains function prototypes and class definitions for parsing,
 * reading and writing an Intel extended HEX file
 *
 * \par Application note:
 * AVR1624: Using ATxmega128A1 Xplain Kit as USB to TWI Bridge
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */
#ifndef HEXPARSER_HPP
#define HEXPARSER_HPP

using namespace std;

#include "ErrorMsg.hpp"
#include "Utility.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>

/** \brief Struct for Intel HEX file 
*/
struct HEXRecord; // Preliminary definition.

/** \brief Class for handling HEX parsing, reading and writing
 */
class HEXFile
{
	protected:
		unsigned char * data; // Holds the data bytes.
		long start, end; // Used data range.
		long size; // Size of databuffer.

		void writeRecord( ofstream & f, HEXRecord * recp );
		void parseRecord( const string & hexLine, HEXRecord * recp );

	public:
		// Constructor 
		HEXFile( long buffersize, long value = 0xff );

		// Destructor
		~HEXFile();

		// Methods 
		void readFile( const string & _filename ); // Read data from HEX file.
		void writeFile( const string & _filename ); // Write data to HEX file.

		void setUsedRange( long _start, long _end ); // Sets the used range.
		void clearAll( long value = 0xff ); // Set databuffer to this value.

		long getRangeStart() { return start; }
		long getRangeEnd() { return end; }
		long getData( long address );
		void setData( long address, long value );
		long getSize() { return size; }
};


#endif

