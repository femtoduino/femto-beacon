/** \file
 *
 * \brief  AVR TWIGEN Commport handler file
 *
 * This file implements modular functions for communicating through COM port
 *
 * \par Application note:
 * AVR1624: Using ATxmega128A1 Xplain Kit as USB to TWI Bridge
 *
 * \par Documentation
 * For comprehensive code documentation, supported compilers, compiler
 * settings and supported devices see readme.html
 *
 * \author
 * Atmel Corporation: http://www.atmel.com \n
 * Support email: avr@atmel.com
 *
 * Copyright (C) 2010 Atmel Corporation. All rights reserved.
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 * Atmel AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

using namespace std;

#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <time.h>

unsigned char g_ucWaitTimeInSeconds;

static BOOL CommPortWaitForData(LPHANDLE pComPortHandle);

/** \brief Opens the COM port with the specified name and gets the handle.
 *
 *  \param pComPortHandle Handle to the COM port used
 *  \param pcComPortName  String containing COM Port number in PC
 *
 *  \return Status - Success or Failure
 */
BOOL CommPortOpen(LPHANDLE pComPortHandle, char *pcComPortName)
{
	//Open the COM Port
	*pComPortHandle = CreateFile(pcComPortName, (GENERIC_READ | GENERIC_WRITE), 0,
                                 NULL, OPEN_EXISTING, 0, NULL);

	//Check to make sure that it is a valid HANDLE
	if(*pComPortHandle == INVALID_HANDLE_VALUE) {
		return(FALSE);
	}

	return(TRUE);
}

/** \brief Initializes the COM port with the specified handle at
 *         the specified baudrate.
 *
 *  \param pCommPortHandle     Handle to the COM port used
 *  \param ulBaudrate          Baudrate for communication on COM port
 *  \param ucWaitTimeInSeconds Timeout period for COM port
 *
 *  \return Status - Success or Failure
 */
BOOL CommPortInit(LPHANDLE pCommPortHandle, unsigned long ulBaudRate, unsigned char ucWaitTimeInSeconds)
{
	DCB NewDCB;
	COMMTIMEOUTS NewCOMMTIMEOUTS;

	g_ucWaitTimeInSeconds = ucWaitTimeInSeconds;

	//Get the current COM port state so we don't have to fill out the entire
	//DCB structure.  If the function fails, return FALSE
	if(GetCommState(*pCommPortHandle, &NewDCB) == FALSE) {
		return(FALSE);
	}

	//modify the DCB structure as necessary.
	NewDCB.BaudRate = ulBaudRate;
	NewDCB.fParity = FALSE;
	NewDCB.fOutxCtsFlow = FALSE;
	NewDCB.fOutxDsrFlow = FALSE;
	NewDCB.fDtrControl = DTR_CONTROL_ENABLE;
	NewDCB.ByteSize = 8;
	NewDCB.Parity = NOPARITY;
	NewDCB.StopBits = ONESTOPBIT;

	//write the new COM port state.  If the function fails, return FALSE
	if(SetCommState(*pCommPortHandle, &NewDCB) == FALSE) {
		return(FALSE);
	}

	//Set the desired COM port timeouts
	NewCOMMTIMEOUTS.ReadIntervalTimeout = 8000;    
	NewCOMMTIMEOUTS.ReadTotalTimeoutMultiplier = 8000;     
	NewCOMMTIMEOUTS.ReadTotalTimeoutConstant = 8000;   
	NewCOMMTIMEOUTS.WriteTotalTimeoutMultiplier = 8000;
	NewCOMMTIMEOUTS.WriteTotalTimeoutConstant = 8000;  

	//write the COM port timeouts.  If the function fails, return FALSE
	if(SetCommTimeouts(*pCommPortHandle, &NewCOMMTIMEOUTS) == FALSE) {
		return(FALSE);
	}

	return(TRUE);
}

/** \brief Closes the COM port with the specified handle.
 *
 *  \param pComPortHandle Handle to the COM port used
 *
 *  \return Status - Success or Failure
 */
BOOL CommPortClose(LPHANDLE pComPortHandle)
{
	//Close the handle.  If it fails, return false
	if(CloseHandle(*pComPortHandle) == FALSE) {
		return(FALSE);
	}

	return(TRUE);
}

/** \brief Transmits the specified data out the specified COM port.
 *
 *  \param pComPortHandle Handle to the COM port used
 *  \param pcData         String containing data to be transmitted
 *  \param ulNumBytes     Number of bytes to be transmitted
 *
 *  \return Status - Success or Failure
 */
BOOL CommPortTx(LPHANDLE pComPortHandle, unsigned char *pcData, unsigned long ulNumBytes)
{
	unsigned long ulActualNumBytes;

	//Transmit the data.  If the write fails, return FALSE
	if(WriteFile(*pComPortHandle, pcData, ulNumBytes, &ulActualNumBytes, NULL) == FALSE) {
	return(FALSE);
	}

	//Check to make sure that the correct number of bytes were tranmsitted
	if(ulNumBytes != ulActualNumBytes) {
		return(FALSE);
	}

	return(TRUE);
}

/** \brief Receives the specified amount data in from the specified COM port
 *         into the specified buffer.
 *  \param pComPortHandle Handle to the COM port used
 *  \param pcData         String to hold received from COM port
 *  \param ulNumBytes     Number of bytes to be received
 *
 *  \return Status - Success or Failure
 */
BOOL CommPortRx(LPHANDLE pComPortHandle, unsigned char *pcData, unsigned long ulNumBytes)
{
	unsigned long ulActualNumBytes;

	if(CommPortWaitForData(pComPortHandle) == FALSE) {
		return(FALSE);
	}

	//Receive the data.  If the receive fails, return FALSE
	if(ReadFile(*pComPortHandle, pcData, ulNumBytes, &ulActualNumBytes, NULL) == FALSE) {
		return(FALSE);
	}

	//Check to make sure that the correct number of bytes were received.
	if(ulNumBytes != ulActualNumBytes) {
		return(FALSE);
	}

	return(TRUE);
}
/** \brief Gets the last error
 *
 *  \return Last error value
 */
DWORD CommPortGetLastError(void)
{
	return(GetLastError());
}

/** \brief Flushes the buffer holding received data
 *
 *  \param pComPortHandle Handle to the COM port used
 *
 *  \return Status - Success or Failure
 */
BOOL CommPortFlushRxBuffer(LPHANDLE pComPortHandle)
{
	unsigned char ucData;
	DWORD dwError;
	COMSTAT csComStat;
	DWORD dwCnt;

	while(1) {
		if(ClearCommError(*pComPortHandle, &dwError, &csComStat) != FALSE) {
			if(csComStat.cbInQue == 0) {
				break;
			}

			for(dwCnt = 0; dwCnt < csComStat.cbInQue; dwCnt++) {
				if(CommPortRx(pComPortHandle, &ucData, 1) == FALSE) {
					//error
					return(FALSE);
				}
			}
		}
		else {
			//error
			return(FALSE);
		}
	}

	return(TRUE);
}

/** \brief Checks whether specified COM port if ready to receive
 *
 *  \param pComPortHandle   Handle to COM port used
 *  \param ulNumBytes Avail Pointer to number of bytes available
 *
 *  \return Status - Success or Failure
 */
BOOL CommPortRxReady(LPHANDLE pComPortHandle, unsigned long *ulNumBytesAvail)
{
	unsigned char ucData;
	DWORD dwError;
	COMSTAT csComStat;

	if(ClearCommError(*pComPortHandle, &dwError, &csComStat) != FALSE) {
		*ulNumBytesAvail = csComStat.cbInQue;
		return(TRUE);
	}
	else {
		*ulNumBytesAvail = 0;
		return(FALSE);
	}
}

/** \brief Waits for data and checks timeout
 *
 *  \param pComPortHandle Handle to COM port used
 *
 *  \return Status - Success or Failure
 */
static BOOL CommPortWaitForData(LPHANDLE pComPortHandle)
{
	unsigned long ulByteCount;
	time_t sStartTime, sCurrentTime;

	sStartTime = time(NULL);

	do {
		sCurrentTime = time(NULL);
		if((sCurrentTime - sStartTime) >= g_ucWaitTimeInSeconds) {
			return(FALSE);
		}
		if(CommPortRxReady(pComPortHandle, &ulByteCount) == FALSE) {
			return(FALSE);
		}
	}while(ulByteCount == 0);

	return(TRUE);
}
